package csvpackage;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author stefan
 */
import com.opencsv.CSVReader;
import java.io.FileReader;
import java.util.Arrays;
import com.opencsv.CSVWriter;

public class readcsvfile {
    public static void main(String[] args) {
        try{
            
            CSVReader reader = new CSVReader(new FileReader("c:/sample.csv"));
            String [] nextline;
            while((nextline=reader.readNext())!= null)
            {
                if(nextline !=null )
                {
                    System.out.println(Arrays.toString(nextline));
                }
            }
        
        } catch(Exception e)
        {
            System.out.println(e);
        }
          System.out.println("CSV Read Complete");
        
    }
}
