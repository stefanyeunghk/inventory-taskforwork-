/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package addinventory;

/**
 *
 * @author stefan
 */
public class inventorystore {
    private String code;
    private String productname;
    private Double weight;
    private String location;
    private Integer quantity;
    
    public String getcode(){
        return code;
    }
    public void setcode(String code){
        this.code = code;
    }
    
    
    public String getproductname(){
        return productname;
    }
    public void setproductname(String productname){
        this.productname = productname;
    }
    public Double getweight(){
        return weight;
    }
    public void setweight(Double weight){
        this.weight = weight;
    }
    public String getlocation(){
        return location;
    }
    public void setlocation(String location){
        this.location = location;
    }
    public Integer getquantity(){
        return quantity;
    }
    public void setquantity(Integer quantity){
        this.quantity = quantity;
    }
}
